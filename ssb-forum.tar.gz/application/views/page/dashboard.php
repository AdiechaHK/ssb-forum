

<div class="main-content">

  <div class="row">
    <?php foreach ($groups as $group) { ?>
    <div class="col-md-3">
      <div class="group-block">
        <h4> <?=$group->title?> </h4>
        <p> <?=$group->description?> </p>
        <?=anchor('/group/show/' . $group->id,
          "Details " . ($group->total_count == $group->read_count ?"":"<i class=\"glyphicon glyphicon-flash\"></i>"),
          array('class' => "btn btn-default"))?>
      </div>
    </div>
    <?php } ?>
  </div>

  <br/>
</div>
.