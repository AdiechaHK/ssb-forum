<!DOCTYPE html>
<html lang="en" data-ng-app="app">
<head>
	<title>DEMO WELCOME</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url('public/css/app.css')?>">
</head>
<body>
