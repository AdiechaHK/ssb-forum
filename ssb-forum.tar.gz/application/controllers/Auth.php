<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

  /**
   * Index Page for this controller.
   *
   * Maps to the following URL
   *    http://example.com/index.php/welcome
   *  - or -
   *    http://example.com/index.php/welcome/index
   *  - or -
   * Since this controller is set as the default controller in
   * config/routes.php, it's displayed at http://example.com/
   *
   * So any other public methods not prefixed with an underscore will
   * map to /index.php/welcome/<method_name>
   * @see http://codeigniter.com/user_guide/general/urls.html
   */

  public function login() {

    $this->load->model('User_model', 'user');
    $user = $this->user->get_conditional_entry(array(
      'email' => $this->input->post('email')
    ));

    if($user == null) {
      echo "User not found !";
    } else {
      if($user->password == md5($this->input->post('password'))) {
        $this->session->set_userdata('auth_user', $user);
        redirect('/dashboard');
      } else {
        echo "Invalid password";
      }
    }
  }

  public function register() {
      $this->load->model('User_model', 'user');
      $save = $this->user->insert_entry(array(
        "username" => $this->input->post('username'),
        "email" => $this->input->post('email'),
        "password" => md5($this->input->post('password')),
        "batch" => $this->input->post('batch')
      ));
      echo "Reg Done !";
  }

  public function logout() {
    $this->session->sess_destroy();
    redirect('/');
  }
}
